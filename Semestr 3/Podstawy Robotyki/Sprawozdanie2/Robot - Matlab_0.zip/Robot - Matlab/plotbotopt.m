%PLOTBOTOPT Define options for robot plotting
%
% Default options for robot/plot function.

% $Log: plotbotopt.m,v $
% Revision 1.1  2002/04/01 11:47:15  pic
% General cleanup of code: help comments, see also, copyright, remnant dh/dyn
% references, clarification of functions.
%
% $Revision: 1.1 $
% Copyright (C) 2001-2002, by Peter I. Corke

function o = plotbotopt
	o = {'base' 'perspective' };
