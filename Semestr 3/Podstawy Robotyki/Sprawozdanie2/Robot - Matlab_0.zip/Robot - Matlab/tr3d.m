function tr3dn(varargin)
% function tr3d(T1, T2, ..., TN)
% parametrami funkcji s� macierze przekszta�cenia jednorodnego, 
% kt�re maj� zosta� zwizualizowane
for i = 1:nargin,
   inp = varargin{i};
   n = inp(1:3, 1);
   o = inp(1:3, 2);
   a = inp(1:3, 3);
   p = inp(1:3, 4);
   
   lxx = [p(1) p(1)+n(1)];
   lxy = [p(2) p(2)+n(2)];
   lxz = [p(3) p(3)+n(3)];
   
   lyx = [p(1) p(1)+o(1)];
   lyy = [p(2) p(2)+o(2)];
   lyz = [p(3) p(3)+o(3)];
   
   lzx = [p(1) p(1)+a(1)];
   lzy = [p(2) p(2)+a(2)];
   lzz = [p(3) p(3)+a(3)];
   
   vargout{(i-1)*12+1} = lxx;
   vargout{(i-1)*12+2} = lxy;
   vargout{(i-1)*12+3} = lxz;      
   vargout{(i-1)*12+4} = 'r';

   vargout{(i-1)*12+5} = lyx;
   vargout{(i-1)*12+6} = lyy;
   vargout{(i-1)*12+7} = lyz;      
   vargout{(i-1)*12+8} = 'g';
   
   vargout{(i-1)*12+9} = lzx;
   vargout{(i-1)*12+10} = lzy;
   vargout{(i-1)*12+11} = lzz;
   vargout{(i-1)*12+12} = 'b';
   
   
   r = vargout;

   plot3(r{:});

   axis equal
   axis on
   grid on
   xlabel('X')
   ylabel('Y')
   zlabel('Z')
   
   dl=0.9;

T_rot11=inp(1,1)*dl;
T_rot12=inp(1,2)*dl;
T_rot13=inp(1,3)*dl;
T_rot21=inp(2,1)*dl;
T_rot22=inp(2,2)*dl;
T_rot23=inp(2,3)*dl;
T_rot31=inp(3,1)*dl;
T_rot32=inp(3,2)*dl;
T_rot33=inp(3,3)*dl;
text(T_rot11,T_rot21,T_rot31,'\leftarrow X',...
     'HorizontalAlignment','left')
    text(T_rot12,T_rot22,T_rot32,'\leftarrow Y',...
     'HorizontalAlignment','left')
    text(T_rot13,T_rot23,T_rot33,'\leftarrow Z',...
     'HorizontalAlignment','left')
end
