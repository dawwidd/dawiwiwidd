#include "wezel.hpp"

Wezel::~Wezel() {
    std::cout<<"Destrukcja obiektu"<<std::endl;
}