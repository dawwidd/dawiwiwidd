#pragma once

#include "Osoba.h"

//Zadanie 24
class FabrykaOsob
{
public:
    virtual Osoba* utworz()=0;
};