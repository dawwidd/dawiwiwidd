#include "FabrykaPracownikow.h"


//Zadanie 26
Pracownik* FabrykaPracownikow::utworz()
{
    Pracownik *s = new Pracownik;
    return s;
}