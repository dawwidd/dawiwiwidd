#include "FabrykaStudentow.h"

//Zadanie 25
Student* FabrykaStudentow::utworz()
{
    Student *s = new Student;
    return s;
}