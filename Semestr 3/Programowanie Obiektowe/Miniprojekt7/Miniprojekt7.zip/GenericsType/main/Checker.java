package main;

//Zadanie 2
public interface Checker<T> {
    boolean check(T object);
}
