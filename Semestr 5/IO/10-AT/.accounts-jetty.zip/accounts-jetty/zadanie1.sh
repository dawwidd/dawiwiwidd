cp -f ./content/accounts1.war ./webapps/accounts.war
java -jar start.jar etc/jetty.xml