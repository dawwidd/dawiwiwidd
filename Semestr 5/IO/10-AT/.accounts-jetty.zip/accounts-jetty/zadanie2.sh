cp -f ./content/accounts2.war ./webapps/accounts.war
java -jar start.jar etc/jetty.xml